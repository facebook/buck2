public class B {
  void bar() {
    new A().foo();
  }
}
