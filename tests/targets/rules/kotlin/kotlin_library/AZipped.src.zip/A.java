// (c) Facebook, Inc. and its affiliates. Confidential and proprietary.

public class A {
  void foo() {
    new B().bar();
  }

  void bar() {}
}
